<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "form_db";

// Koneksi ke database
$conn = new mysqli($host, $user, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form dengan fallback ke string kosong
$nama = $_POST['nama'] ?? '';
$email = $_POST['email'] ?? '';
$pesan = $_POST['pesan'] ?? '';

// Cek kalau data kosong, stop dan kasih pesan
if (empty($nama) || empty($email) || empty($pesan)) {
    die("Error: Semua field harus diisi.");
}

// Siapkan prepared statement untuk mencegah SQL Injection
$stmt = $conn->prepare("INSERT INTO kontak (nama, email, pesan) VALUES (?, ?, ?)");

if (!$stmt) {
    die("Prepare statement error: " . $conn->error);
}

// Bind parameter dan eksekusi query
$stmt->bind_param("sss", $nama, $email, $pesan);

if ($stmt->execute()) {
    echo "Data berhasil dikirim!";
} else {
    echo "Error saat mengirim data: " . $stmt->error;
}

// Tutup statement dan koneksi
$stmt->close();
$conn->close();
?>
